# TOOLS.md — Quick Reference
> Full docs per tool: `memory/tools/<tool>.md` (browser, github, email, ticktick, podcast, tts, whisper, qdrant, excalidraw, moltbook)

## Browser 🌐
- Profile: `openclaw` (NOT `chrome`)
- ⚠️ **НИКОГДА не логиниться в Google** в агентских профилях — все managed-профили (openclaw, construction-demo и др.) делят один Chrome userDataDir, Google Sync сразу виден во всех профилях
- `userDataDir` в конфиге работает ТОЛЬКО для `existing-session` профилей (Brave, Edge), не для managed
- Clicks: `openclaw browser click <ref> --target-id <id>` (browser.act сломан)
- **⚠️ VIEWPORT: ПЕРВЫЙ вызов в любой браузерной задаче = resize 1500×900. БЕЗ ИСКЛЮЧЕНИЙ.**
  ```
  browser(action="act", request={"kind":"resize","width":1500,"height":900})
  ```
  Нет дефолта в конфиге — только per-session. Если не сделать — скриншоты и клики будут по неверным координатам.

## GitHub 🐙
- ✅ **arkasha-ai** (разблокирован 25.02.2026, тикет 4087174)
- Personal account Denis: `topitip` (не трогать для автоматизации!)
- SSH key: `~/.ssh/github_arkasha`
- 2FA: `oathtool --totp --base32 "$(grep GITHUB_2FA_SECRET ~/.openclaw/secrets.env | cut -d= -f2)"`

## Email (Himalaya) 📬
- ⚠️ Всегда флаг `--account <name>`, НЕ env var!
- `dparmeev` / `spam` / `contact` / `contact-lumines` / `arkady`
- My email: `a.parmeev@jakeberrimor.com` → account `arkady`

## Paperclip 📎
- AI-команда: Максим (CEO) + Дмитрий (Engineer)
- API: `https://paperclip.znaemai.ru`
- Credentials: `~/.openclaw/workspace/paperclip-claimed-api-key.json`
- Full docs: `memory/tools/paperclip.md`

## Moltbook 🦞
- Profile: https://moltbook.com/u/Arkasha
- Credentials: `~/.config/moltbook/credentials.json`

## YouTube 📹
- `python3 scripts/youtube_transcript.py <url> [lang]`

## Whisper 🎤
- Endpoint: `https://litellm.jakeberrimor.com`, model: `openai/whisper-large-v3`
- Config: `~/.openclaw/litellm.env`

## Penpot MCP 🎨
- **Всегда использовать для просмотра/поиска/экспорта — не открывать браузер!**
- Сервер: `https://penpot-mcp.jakeberrimor.com/sse`
- Config: `~/.openclaw/workspace/config/mcporter.json`
- Команды:
  ```bash
  mcporter call penpot-mcp.search_object --args '{"file_id":"<id>","query":"<regex>"}' --output json
  mcporter call penpot-mcp.get_object_tree --args '{"file_id":"<id>","object_id":"<oid>"}' --output json
  mcporter call penpot-mcp.export_object --args '{"file_id":"<id>","object_id":"<oid>","scale":2,"format":"png"}' --output json
  mcporter call penpot-mcp.get_file --args '{"file_id":"<id>"}' --output json
  ```
- Если export_object не работает → API export через requests POST `/api/export` (см. `/tmp/nota_final.py`)
- Рабочий файл: `memory/state/penpot-nota.json`

## MindGraph 🧠
- Сервер: `http://127.0.0.1:18790` (автостарт @reboot)
- Токен: `MINDGRAPH_TOKEN` из `~/.openclaw/secrets.env`
- Поиск: `POST /retrieve {"action":"text","query":"...","limit":5}`
- Entity: `POST /reality/entity {"action":"create","agent_id":"arkasha","label":"...","props":{"entity_type":"Person"}}`
- Сессия: `POST /memory/session {"action":"open","agent_id":"arkasha","label":"..."}`
- Health: `curl http://127.0.0.1:18790/health`
- Клиент: `skills/mindgraph-rs/mindgraph-client.js`
- ⚠️ Старый KuzuDB граф: `archive/knowledge-graph-kuzu/` (не используется)

## Qdrant 🔍
- `python3 scripts/qdrant_indexer.py search "запрос"`
- `python3 scripts/qdrant_indexer.py index-emails`

## TickTick 🎯
- IDs: Личный `695bc6dd7d799105bb21e874` / Работа `695bc7447dd51105bb21e8ee`
- Фитнес `695bfa4ba268d125f73668e9` / Back-end `695bfb43ab63d125f7366aa6`

## IMAP IDLE 📧
- Script: `scripts/imap_idle_listener_v2.py` (4 accounts, instant webhooks)
- Check: `ps aux | grep imap_idle_listener_v2`

## Excalidraw ✏️
- ⚠️ **NO EMOJI в тексте** — не рендерятся! Заменять: ✅→`[OK]`, ⚠️→`[!]`

## TTS 🔊
- Voice: `ru-RU-DmitryNeural` (Edge TTS, бесплатно)
- Только по запросу! Без эмодзи и markdown в тексте для голоса.
- **Голосовые сообщения:** ВСЕГДА через `message(action=send, asVoice=true, filePath=<mp3>)` — НЕ через tts tool напрямую (отправляется как аудиофайл, а не voice message)

## Podcast 🎙️
- Script: `scripts/podcast_generator_yandex_v3.py`
- Голоса: `ermil` +30Hz (host1), `alena` +20Hz (host2), speed: 1.05x
- Credentials: `~/.openclaw/secrets.env` (YANDEX_API_KEY_ID, YANDEX_API_SECRET)

## Documents 📄
- **DOCX:** `python-docx` (создание, редактирование) → skill `docx-mastery`
- **XLSX:** `openpyxl` (таблицы, charts, dashboards) → skill `excel-mastery`
- **PPTX:** `python-pptx` (презентации, КП) → skill `pptx-mastery`
- **PDF из Markdown:** `pandoc --pdf-engine=xelatex` (кириллица, таблицы, шрифты DejaVu)
- **PDF из LaTeX:** `pdflatex` (полный контроль) или `xelatex` (Unicode шрифты TTF/OTF)
- **PDF из HTML:** Playwright print-to-pdf (карточки, визуал)
- **Чтение PDF:** `pdf` tool (встроенный) или `pandoc file.pdf -o out.md`
- **Чтение DOCX:** `pandoc file.docx -o out.md` или python-docx
- Диаграммы/схемы → Excalidraw skill

### Быстрые команды
```bash
# Markdown → PDF (кириллица)
pandoc doc.md -o doc.pdf --pdf-engine=xelatex -V mainfont="DejaVu Serif" -V geometry:margin=2cm

# CSV → Excel (форматированный)
python3 skills/excel-mastery/scripts/csv_to_excel.py data.csv report.xlsx

# JSON → DOCX
python3 skills/docx-mastery/scripts/create_docx.py spec.json output.docx

# JSON → PPTX
python3 skills/pptx-mastery/scripts/create_pptx.py spec.json output.pptx
```

## Gravity Docs 📄
- Заявки: `scripts/gravity_zavka_generator_v2.py`
- Шаблон: `~/.openclaw/media/inbound/file_81---2141837f-9e85-45e3-9135-f0ffbf7ac458.docx`
- Full docs: `memory/projects/gravity-docs.md`
